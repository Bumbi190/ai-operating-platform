# Build Reproducibility Report — ATLAS KNOWLEDGE EDITION v1.0 — LOCAL VALIDATION CANDIDATE 2

- Build scripts use `pathlib` + argparse CLI (`--workspace-root`, `--output-dir`, `--help`). No hardcoded session paths.
- Preflight verifies all input checksums and FAILS CLOSED on any missing source or wrong SHA.
- The build writes only under a staging directory inside `--output-dir`, then atomically finalizes (os.replace).
- No git, no network, no dependency installation. Requires system tool `pdftotext` (poppler), presence checked in preflight.
- Candidate 2 was produced by running the scripts, not by manual post-hoc files.

## Reproducible command
```
python3 Build/build_atlas.py \
  --workspace-root "<path>/executive-intelligence" \
  --output-dir     "<path>/executive-intelligence"
python3 Build/run_retrieval_tests.py --package-root "<path>/Executive Intelligence — Atlas Knowledge Edition v1.0 — Validation Candidate 2"
```
