# Canonical Target vs Implemented Runtime

Status: ATLAS KNOWLEDGE EDITION v1.0 — LOCAL VALIDATION CANDIDATE

## Rule

Canonical doctrine describes the **canonical target architecture**. It does not assert that any
described capability exists in the running system. This package therefore sets:

```
implementation_status: unknown_not_verified_in_this_package
```

on every canonical section record, because this phase is not permitted to inspect or modify the
Omnira repository, schema, runtime, or deployment.

## Authoritative sources of truth for implementation

Repository, schema, runtime, and deployment are authoritative for what is actually implemented.
Documents, Memory, Knowledge, graph objects, and model outputs are **not**.

## Maturity metadata used in this package

- `canonical_target` — present on every section (it is canonical doctrine).
- `stage_1_explicit` — the section text explicitly mentions "Stage 1".
- `future_explicit` — the section text explicitly mentions the future/target architecture.
- `implementation_status: unknown_not_verified_in_this_package` — actual runtime status is not verified here.

The statuses `implemented`, `partially_implemented`, and `deprecated` are **not** used anywhere
in this package, because they require runtime/repository verification that is out of scope.

## Canonical anchor (quoted with citation)

> Canonical target architecture does not mean that every described capability is implemented. The actual repository, schema, runtime, and deployment state is the authoritative source for what exists in production. Atlas and future implementations must distinguish between canonical target architecture, implemented, partially implemented, planned, not implemented, and deprecated.

Source: Omnira — Executive Intelligence — Canonical v1.0 · Front Matter · Canonical Doctrine Notice · Professional Edition p.3–6
