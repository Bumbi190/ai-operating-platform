# Human Authority and Approval

Status: ATLAS KNOWLEDGE EDITION v1.0 — LOCAL VALIDATION CANDIDATE

## Rule

Human authority, governance, approval gates, and project isolation always apply. Knowledge
retrieved from this package is evidence and context — never execution authority.

- A recommendation does not automatically become a decision.
- A decision does not automatically become an approval.
- An approval does not automatically become reusable policy or autonomy.
- Autonomy is never self-granted (see canonical §18.80 "No Self-Promotion",
  §18.247 "Anti-Self-Promotion Principle", §18.62 "Trust Does Not Transfer Automatically").

## Canonical anchors

- Ultimate/founder authority: §32.15 (The Founder Defines Legitimacy), §1.10 (Human Authority and
  Earned Autonomy), §19.194 (Human Review Authority).
- Object separation: Front Matter §FM.3 (How to Read This Book).
- When approval is required: §16.28 (Require Approval), §16.19 (Stricter-Rule Principle).

## Retrieval obligation

Any query that concerns authority, approval, autonomy, or external action MUST surface the
warning flags defined in `../05_Retrieval/query-routing-rules.md`. Retrieval answers must cite
the canonical source and must not be treated as an instruction to act.
