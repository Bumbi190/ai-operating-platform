# Knowledge Authority Rules — Atlas Knowledge Edition v1.0

Status: ATLAS KNOWLEDGE EDITION v1.0 — LOCAL VALIDATION CANDIDATE
Canonical input status: Approved and locked — Canonical v1.0

## Absolute knowledge rules (binding for every consumer of this package)

- Canonical target architecture is not the same as implemented runtime.
- Repository, schema, runtime, and deployment are authoritative for what is actually implemented.
- Documents, Memory, Knowledge, graph objects, or model outputs never create authority.
- Human authority, governance, approval gates, and project isolation still apply.
- A recommendation does not automatically become a decision.
- A decision does not automatically become an approval.
- An approval does not automatically become reusable policy or autonomy.
- Knowledge is evidence and context, not execution authority.
- The Atlas Knowledge Edition never grants Atlas the right to act outside existing runtime authority.

## What this package is

The Atlas Knowledge Edition is a machine-readable, traceable, retrieval-optimized representation
of the already-locked Canonical v1.0 text. It is **not** a new book and **not** new doctrine.
Every canonical record carries source provenance back to Canonical v1.0 and the Final
Professional Edition page range.

## What this package is not

- It is not an execution grant. Retrieving a section never authorizes an action.
- It is not an implementation record. See `CANONICAL_VS_RUNTIME.md`.
- It does not contain embeddings or a vector database. Ingestion happens later, in the Omnira
  repository, with the approved retrieval architecture.

## Canonical anchor

The object-separation doctrine (recommendation ≠ decision ≠ approval ≠ policy ≠ autonomy) is
stated in Canonical Front Matter §FM.3 (How to Read This Book). The canonical-vs-runtime and
"no automatic execution authority" doctrine is stated in Front Matter §FM.1 (Canonical Doctrine
Notice). These are quoted with citation in the companion governance files.
