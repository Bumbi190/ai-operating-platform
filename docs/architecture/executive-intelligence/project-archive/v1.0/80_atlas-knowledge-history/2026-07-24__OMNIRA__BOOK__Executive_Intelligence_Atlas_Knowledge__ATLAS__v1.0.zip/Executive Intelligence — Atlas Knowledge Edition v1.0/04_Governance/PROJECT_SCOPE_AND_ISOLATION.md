# Project Scope and Isolation

Status: ATLAS KNOWLEDGE EDITION v1.0 — LOCAL VALIDATION CANDIDATE

## Rule

Project isolation is an executive requirement, not only a technical one. Executive scope,
Decision Ledger entries, autonomy licenses, and approvals are project-scoped. Knowledge about one
project does not transfer authority to another.

## Canonical anchors

- Project isolation as an executive requirement: §2.19.
- Project isolation & executive boundaries: Chapter 6 (see `../02_Indexes/chapter-index.json`).
- Decision Ledger isolation / explicit scope: §6.35.
- Portfolio vs Project executive boundary: §1.11, §5.4.

## Projects named in canonical text

Omnira, The Prompt, Familje-Stunden, GainPilot. See `../02_Indexes/project-index.json` for the
exact sections that name each project. Project scope in section records is derived from explicit
project-name mentions only; no project relationships are inferred.
