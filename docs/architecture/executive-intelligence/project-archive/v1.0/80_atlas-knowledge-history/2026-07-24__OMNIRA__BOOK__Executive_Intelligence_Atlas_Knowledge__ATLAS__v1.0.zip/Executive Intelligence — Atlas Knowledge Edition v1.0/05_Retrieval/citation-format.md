# Citation Format

Status: ATLAS KNOWLEDGE EDITION v1.0 — LOCAL VALIDATION CANDIDATE

Every canonical answer must cite its source using the section record `citation_label`:

```
Omnira — Executive Intelligence — Canonical v1.0 · Ch <n> §<section_id> · <section_title> · Professional Edition p.<start>[–<end>]
```

Front matter uses:

```
Omnira — Executive Intelligence — Canonical v1.0 · Front Matter · <heading> · Professional Edition p.3–6
```

- Canonical source SHA-256: `ee85a1a09968c585530869bcc8d06eda16e4e12a8d5b6f856af362e10fa555b8`
- Final Professional Edition SHA-256: `b0cbb84eb0a53265bcc03b97c5c780e436489aaacdde1e7092816aa039be6aa2`
- Page numbers are the Final Professional Edition physical pages (of 1740), derived from the final PDF.
