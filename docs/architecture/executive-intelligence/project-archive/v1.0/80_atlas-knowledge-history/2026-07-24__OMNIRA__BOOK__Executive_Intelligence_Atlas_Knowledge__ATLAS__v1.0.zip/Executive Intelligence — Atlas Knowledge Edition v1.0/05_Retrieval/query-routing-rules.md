# Query Routing Rules (deterministic)

Status: ATLAS KNOWLEDGE EDITION v1.0 — LOCAL VALIDATION CANDIDATE

Routing is deterministic: exact section-ID lookup, chapter lookup, concept postings, project
postings, authority-class postings, and stage/future scope. No generative phrasing, no embeddings.

## Warning-flag rules

| Condition (query tag) | Warning flag |
|---|---|
| always | `IMPLEMENTATION_STATUS_UNVERIFIED` |
| `authority` | `AUTHORITY_QUERY_HUMAN_OVERSIGHT_REQUIRED` |
| `external_action` | `EXTERNAL_ACTION_NOT_EXECUTION_AUTHORITY` |
| `autonomy` | `AUTONOMY_NOT_SELF_GRANTED` |
| `approval` | `APPROVAL_GATE_APPLIES` |
| `maturity` | `CANONICAL_TARGET_NOT_CONFIRMED_IMPLEMENTED` |
| `stage_scope` | `STAGE_SCOPE_IS_ARCHITECTURAL_TARGET` |
| `emergency` | `EMERGENCY_CONTROL_HUMAN_GOVERNED` |
| `knowledge_evidence` | `KNOWLEDGE_IS_EVIDENCE_NOT_EXECUTION_AUTHORITY` |

## Routing order

1. If the query contains an exact section ID → return that section record + citation.
2. Else map the query to a concept/project/authority class and return the posted sections in
   canonical order.
3. Always return canonical text first; return `NON-CANONICAL RETRIEVAL AID` summaries separately.
4. Always attach `implementation_status: unknown_not_verified_in_this_package` and the applicable warning flags.
