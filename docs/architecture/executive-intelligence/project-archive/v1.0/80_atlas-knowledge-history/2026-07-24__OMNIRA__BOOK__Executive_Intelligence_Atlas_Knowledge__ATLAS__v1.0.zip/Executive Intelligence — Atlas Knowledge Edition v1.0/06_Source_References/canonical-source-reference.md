# Canonical Source Reference

- Title: Omnira — Executive Intelligence — Canonical Architecture and Operating Doctrine
- Version: 1.0 — Approved and locked — Canonical v1.0
- Canonical compiled book SHA-256: `ee85a1a09968c585530869bcc8d06eda16e4e12a8d5b6f856af362e10fa555b8`
- Chapters: 32 · Section IDs: 6705 · Front matter sections: 4
- This package derives all canonical content from the compiled canonical book (via the verified
  `content_map.json`, whose recorded source SHA matches the canonical book).

Per-chapter canonical source SHA-256 values are listed in `source-map.json`.
