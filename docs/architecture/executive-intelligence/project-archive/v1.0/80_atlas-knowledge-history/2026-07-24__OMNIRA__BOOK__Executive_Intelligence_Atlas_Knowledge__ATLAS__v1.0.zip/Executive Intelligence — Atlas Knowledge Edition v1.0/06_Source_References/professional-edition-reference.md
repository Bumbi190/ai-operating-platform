# Final Professional Edition Reference

- File: Omnira — Executive Intelligence — Professional Edition v1.0.pdf
- SHA-256: `b0cbb84eb0a53265bcc03b97c5c780e436489aaacdde1e7092816aa039be6aa2`
- Pages: 1740 · Chapters: 32 · Navigational Parts: 10 · Active diagrams: 17
- Page numbers used throughout this package are Final Professional Edition physical pages,
  extracted from this exact PDF.
- The historical withdrawn integration diagram (between D13 and D15) is excluded from the active
  edition and not imported here.
