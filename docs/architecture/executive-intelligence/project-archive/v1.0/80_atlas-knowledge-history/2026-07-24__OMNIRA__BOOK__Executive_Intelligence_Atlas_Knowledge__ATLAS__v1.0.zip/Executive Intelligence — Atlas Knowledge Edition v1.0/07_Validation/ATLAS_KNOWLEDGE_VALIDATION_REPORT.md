# Atlas Knowledge Validation Report

Package status: ATLAS KNOWLEDGE EDITION v1.0 — LOCAL VALIDATION CANDIDATE
Date: 2026-07-15
Overall: ALL CHECKS PASS

## Checks

- PASS — chapter_files_32
- PASS — section_records_6705
- PASS — block_records_55840
- PASS — front_matter_sections_4
- PASS — canonical_order_preserved
- PASS — no_duplicate_section_ids
- PASS — no_missing_section_ids
- PASS — no_candidate_build_version_markings_in_canonical_text
- PASS — no_D14_in_active_edition
- PASS — active_diagram_count_17
- PASS — no_new_doctrine
- PASS — no_speculative_relationships
- PASS — all_canonical_records_have_provenance
- PASS — all_navigational_aids_labelled_NCA
- PASS — canonical_sha_unchanged
- PASS — final_pdf_sha_unchanged
- PASS — retrieval_tests_all_pass

## Source integrity (before vs after)

- Canonical v1.0 SHA-256 expected `ee85a1a09968c585530869bcc8d06eda16e4e12a8d5b6f856af362e10fa555b8` — now `ee85a1a09968c585530869bcc8d06eda16e4e12a8d5b6f856af362e10fa555b8` — UNCHANGED
- Final Professional Edition SHA-256 expected `b0cbb84eb0a53265bcc03b97c5c780e436489aaacdde1e7092816aa039be6aa2` — now `b0cbb84eb0a53265bcc03b97c5c780e436489aaacdde1e7092816aa039be6aa2` — UNCHANGED
