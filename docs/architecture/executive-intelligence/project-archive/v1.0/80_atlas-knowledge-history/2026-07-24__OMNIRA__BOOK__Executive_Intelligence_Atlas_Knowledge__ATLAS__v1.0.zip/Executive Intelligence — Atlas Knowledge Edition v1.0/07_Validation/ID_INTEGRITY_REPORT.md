# ID Integrity Report

- Unique section IDs: 6705 / 6705 — OK
- Section order matches Canonical v1.0 order: OK
- Block ordinals contiguous 1..55840: OK
- knowledge_id scheme: sections `AKE-EI-<section_id>`, front matter `AKE-FM-<n>`, blocks `AKE-B-<ordinal>`.
- Every block has `source_reference` + `canonical_sha256`: OK
- Every section has `citation_label` + `canonical_sha256`: OK
- Every section additionally carries `section_text_sha256` for tamper-evidence.
