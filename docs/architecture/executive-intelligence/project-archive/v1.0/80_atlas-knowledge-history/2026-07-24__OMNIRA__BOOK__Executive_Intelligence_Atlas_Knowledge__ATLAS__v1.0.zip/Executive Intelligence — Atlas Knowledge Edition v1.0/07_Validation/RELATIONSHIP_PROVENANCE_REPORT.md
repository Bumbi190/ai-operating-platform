# Relationship Provenance Report

- Total explicit relationship records: 73
- Confidence values used: ['explicit', 'structurally_explicit'] (only `explicit` and `structurally_explicit` permitted)
- No `inferred`, `probable`, or `speculative` relationships: OK

## Provenance breakdown

- part_contains_chapter (Professional Edition navigation, structurally_explicit, non-canonical): 32
- chapter_anchors_diagram (presentation layer, structurally_explicit, non-canonical): 17
- diagram_derived_from_sections (structurally_explicit, non-canonical): 17
- references_chapter (canonical prose, explicit): 7

Canonical prose contains no §/"Section N.M" cross-references; therefore section→section links are
limited to the 7 explicit textual chapter references. No semantic doctrine relationships were synthesized.
