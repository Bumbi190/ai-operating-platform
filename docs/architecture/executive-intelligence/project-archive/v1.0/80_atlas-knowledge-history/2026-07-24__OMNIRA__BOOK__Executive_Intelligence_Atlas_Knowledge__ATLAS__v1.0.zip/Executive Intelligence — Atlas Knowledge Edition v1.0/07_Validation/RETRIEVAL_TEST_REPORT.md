# Retrieval Test Report

- Deterministic retrieval test cases: 46 (requirement: ≥ 40)
- Passed: 46 / 46
- Method: exact section-ID lookup, chapter match, citation resolution, and deterministic
  warning-flag routing. No generative phrasing and no embeddings are tested.
- Machine-readable results: `retrieval-tests.jsonl`.

Each test verifies: (1) all expected section IDs exist, (2) the primary section resolves to the
expected chapter, (3) the citation resolves from the section index, and (4) the query tags produce
the expected warning flags.
