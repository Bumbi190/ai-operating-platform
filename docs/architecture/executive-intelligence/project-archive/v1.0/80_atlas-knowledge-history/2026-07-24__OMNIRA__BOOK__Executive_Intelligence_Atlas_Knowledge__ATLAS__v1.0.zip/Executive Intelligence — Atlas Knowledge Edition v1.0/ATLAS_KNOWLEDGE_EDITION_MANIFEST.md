# Atlas Knowledge Edition — Manifest

- package_version: 1.0
- package_status: ATLAS KNOWLEDGE EDITION v1.0 — LOCAL VALIDATION CANDIDATE
- build_date: 2026-07-15

## Canonical input
- title: Omnira — Executive Intelligence — Canonical v1.0
- canonical_status: Approved and locked — Canonical v1.0
- canonical_sha256: `ee85a1a09968c585530869bcc8d06eda16e4e12a8d5b6f856af362e10fa555b8` (verified before and after build: UNCHANGED)

## Final Professional Edition reference
- file: Omnira — Executive Intelligence — Professional Edition v1.0.pdf
- final_pdf_sha256: `b0cbb84eb0a53265bcc03b97c5c780e436489aaacdde1e7092816aa039be6aa2` (verified before and after build: UNCHANGED)
- pages: 1740

## Counts
- chapters: 32
- sections: 6705
- blocks: 55840
- front_matter_sections: 4
- active_diagrams: 17
- navigational_parts: 10
- relationship_records: 73
- retrieval_tests: 46 (passed 46)

## Tool versions
- python: 3.10.12
- pdftotext version 22.02.0

## Build commands
```
python3 build_atlas.py          # stage A: canonical knowledge, indexes, relationships
python3 build_atlas_docs.py     # stage B: governance, retrieval, source refs, validation, manifest
```

## Validation results
- PASS — chapter_files_32
- PASS — section_records_6705
- PASS — block_records_55840
- PASS — front_matter_sections_4
- PASS — canonical_order_preserved
- PASS — no_duplicate_section_ids
- PASS — no_missing_section_ids
- PASS — no_candidate_build_version_markings_in_canonical_text
- PASS — no_D14_in_active_edition
- PASS — active_diagram_count_17
- PASS — no_new_doctrine
- PASS — no_speculative_relationships
- PASS — all_canonical_records_have_provenance
- PASS — all_navigational_aids_labelled_NCA
- PASS — canonical_sha_unchanged
- PASS — final_pdf_sha_unchanged
- PASS — retrieval_tests_all_pass

Overall: ALL CHECKS PASS

## Known limitations
- Per-section page ranges are derived from Final Professional Edition section-header positions; page_end
  of a section is bounded by the next section's start page and the chapter end page.
- `implementation_status` is `unknown_not_verified_in_this_package` for all records: this phase does not inspect the Omnira repo/runtime.
- Canonical prose contains no §/"Section N.M" cross-references, so section→section links are limited to
  explicit textual chapter references; no semantic doctrine relationships were synthesized.
- Navigational Parts and diagrams are Professional Edition layers (non-canonical) and are labelled as such.
- No embeddings and no vector database were created (out of scope for this phase).

## Authority disclaimer
This package is knowledge, not authority. Retrieval grants no execution rights. Human authority,
governance, approval gates, and project isolation always apply. Canonical target architecture is not
implemented runtime. Repository, schema, runtime, and deployment remain authoritative for what exists.

## File checksums (SHA-256)
| File | SHA-256 |
|---|---|
| `01_Canonical_Knowledge/Chapters/chapter-01-executive-intelligence-manifesto.md` | `240ebb682da3d4a1c1557a3461fb01e573972aab2b1619c5251e46151bdf2f4f` |
| `01_Canonical_Knowledge/Chapters/chapter-02-the-role-of-executive-intelligence-in-omnira.md` | `e2127020bfd32ef4d0eb244d4627714d3ae92ce0d8b9fc4180a17a73ecdbb88b` |
| `01_Canonical_Knowledge/Chapters/chapter-03-executive-vs-workforce-vs-manager.md` | `eba7728238444a1cf2a612f79df7ad37cdf57d8c68d075eace6a93a3d88cf22d` |
| `01_Canonical_Knowledge/Chapters/chapter-04-portfolio-executive-architecture.md` | `de1b9b2229f1cc67cc6824301a37ed30ffeaa72a54a09e9af33a66748a151f69` |
| `01_Canonical_Knowledge/Chapters/chapter-05-project-executive-architecture.md` | `9924da84f079c3c3add49e3564056fc330d79cca37f85e66fb683b22720ca3c0` |
| `01_Canonical_Knowledge/Chapters/chapter-06-project-isolation-and-executive-boundaries.md` | `2e5bced7f6ffe7b2d33a5d524a6bbd8dc785c0a44301ca9e7df90c32463c31ef` |
| `01_Canonical_Knowledge/Chapters/chapter-07-executive-operating-cadence.md` | `1e5f4b59a9828a26260cbf7c0287dcf48fed7c082b98daf9a0cdd9306bff7419` |
| `01_Canonical_Knowledge/Chapters/chapter-08-daily-executive-brief.md` | `60b808005f7b5f0311a502538309bb1ba63fecae68323637420df362b00107ca` |
| `01_Canonical_Knowledge/Chapters/chapter-09-founder-capacity-and-calendar-aware-planning.md` | `750ea1e3937b873d98cc0fd13988709727ad87b1b335e75de166d4f0bba003d4` |
| `01_Canonical_Knowledge/Chapters/chapter-10-decision-intelligence.md` | `d48b495ad7cf2cd3bf5e42f5258dcdfc7c0a7a635591312fb5d0bddc3d22da1e` |
| `01_Canonical_Knowledge/Chapters/chapter-11-decision-ledger.md` | `4e2c20a2e491e3a3c8dfaa367674f5e8e334e0a330b5e2d8dcee480454a62057` |
| `01_Canonical_Knowledge/Chapters/chapter-12-review-dates-and-decision-decay.md` | `2c7344afbc6061175e274ee2ec30229f9c4a771d3ae4b9a4cbc29505f875ceaa` |
| `01_Canonical_Knowledge/Chapters/chapter-13-strategic-planning-and-roadmap-intelligence.md` | `d52048477d3c489c7ea9a9a2f58109101ebce978683345e2a76c4491dee97d62` |
| `01_Canonical_Knowledge/Chapters/chapter-14-prioritization-system.md` | `19f6f2f3364dde384ddb26f58cb0e5bff1e3260acf685e1937c0fb195345cc49` |
| `01_Canonical_Knowledge/Chapters/chapter-15-opportunity-cost-intelligence.md` | `86d9fd7422be12efcb02a1cdb0b77ab115efdaae19a491f5336eea48d271ac14` |
| `01_Canonical_Knowledge/Chapters/chapter-16-governance-and-policy-engine.md` | `73ee7990680446aa7fd03a8024520cfe0150494453c10ee9850440b9aeffc3f4` |
| `01_Canonical_Knowledge/Chapters/chapter-17-damage-boundary.md` | `203ff3da6a6a0c21131340813f0b159dd20715ad3f9bfd4d3b0eeb19d42301ea` |
| `01_Canonical_Knowledge/Chapters/chapter-18-autonomy-licensing-model.md` | `06b8998b2f9f9e9949d6a554d7e8ceabcd7b81bd114ba36a02973560c441431c` |
| `01_Canonical_Knowledge/Chapters/chapter-19-trust-score-and-autonomy-progression.md` | `f4f0248bcf0eecef74b5f0829c88735fcb0ab1d7e6dfeb81e1cd53d9302ef3da` |
| `01_Canonical_Knowledge/Chapters/chapter-20-executive-mission-briefs.md` | `21da71891e9520824637a006c4e2829e0a7e9e2a5e1f6dba93acc8ee0ca1e58d` |
| `01_Canonical_Knowledge/Chapters/chapter-21-workforce-delegation-and-intervention.md` | `5f52fa2bfccae81ffd7ee94fe06ed5a1512ee44e8cd2b438950ece1124fd8c2c` |
| `01_Canonical_Knowledge/Chapters/chapter-22-executive-memory-integration.md` | `03aeee41c4c11ed28cc00950ed7e90a206184c9e41efa50d4c9fcc5b52bb5832` |
| `01_Canonical_Knowledge/Chapters/chapter-23-executive-knowledge-integration.md` | `cc57fa1010d43e4b440971602903185f45deb80bc5cd89e31f873bb550086e4a` |
| `01_Canonical_Knowledge/Chapters/chapter-24-executive-ai-intelligence-integration.md` | `f08ac1896a0e79d7368eba90818452607d448a28a9f77a15093e299a971eb7ed` |
| `01_Canonical_Knowledge/Chapters/chapter-25-executive-performance-intelligence-integration.md` | `cb13beb792c2535b0e93b8ac4d5550bb4ed2018b83ca2d7f49a2abed2a7fd2eb` |
| `01_Canonical_Knowledge/Chapters/chapter-26-executive-graphs-and-transparency.md` | `904f3e1e057f3d0d129377c5437320de70ea7e842ab3ebce898064365e372939` |
| `01_Canonical_Knowledge/Chapters/chapter-27-approval-inbox.md` | `c53607eaa6a5ef6454cfb6cbfbb48c3544e780433e38bb6c8ee406d83a7351e4` |
| `01_Canonical_Knowledge/Chapters/chapter-28-crisis-mode-and-emergency-brake.md` | `ab6a4016134d6e416dd3b80421f76d616d71ecc3a21a5c4cb0afa6e8e8883c93` |
| `01_Canonical_Knowledge/Chapters/chapter-29-policy-violations-and-severity-levels.md` | `d83a97035d18067d2ebe2a00c5e6038161e89d3218ef50ed63a0337351ff928e` |
| `01_Canonical_Knowledge/Chapters/chapter-30-the-prompt-as-first-autonomy-proving-ground.md` | `6cf2638d928b55d45871e80142b73aefe2984dfa90a7bc66959f00b69351a335` |
| `01_Canonical_Knowledge/Chapters/chapter-31-future-full-autonomy.md` | `b8cfa591b7d21aae2dad7a718b32f553fd9a0bd0aeb401355b507afc10c71acf` |
| `01_Canonical_Knowledge/Chapters/chapter-32-final-executive-manifest.md` | `8753dae0a9524ca8dc0ed5deaaea0f3878a9931feafe5c178896091ddd0f574c` |
| `01_Canonical_Knowledge/executive-intelligence-blocks.jsonl` | `cf7777e55ef0cacbc383b832fd917d79fc9ab2afc917c5b21216adf2b2e7052e` |
| `01_Canonical_Knowledge/executive-intelligence-sections.jsonl` | `a485ecf2a491d9a515bdb0fd5cb8dad4891ce82e0a58c1fdd17bf904f1bb5bec` |
| `01_Canonical_Knowledge/front-matter.jsonl` | `7a1a67cfc2343885afe5a9801654392e43819252d549eaacee66989752514c60` |
| `02_Indexes/authority-index.json` | `5a9e6e85743574df41bea952b8c64beec63c6337e03d2c20f5581e6f5252b334` |
| `02_Indexes/autonomy-index.json` | `b3f0335a595890b5fcb13be9b3ebefc7e0c167deeda8a648fca611832276a94b` |
| `02_Indexes/chapter-index.json` | `d33e9892f55903ba7d3e2a96de87e56dd99b8abdc0764492917d3f8f939af322` |
| `02_Indexes/concept-index.json` | `de7b1bd738c72eec7d7c446c1199d358e572d129ecf344199649303c6ccd2259` |
| `02_Indexes/decision-and-approval-index.json` | `f7aebb0893ec23cbfa73e03fdcaf040c9c6547eb9b253dd7712b39cf30f268d3` |
| `02_Indexes/diagram-index.json` | `783e0927de2bbb2ff26997a821da2c7800e5f3d71bd4cf270f8407221df723ff` |
| `02_Indexes/governance-index.json` | `6552c3f3dc34a7fb8bb279120f1e6c8d3a678f48c33f477b8f96cbfc97316c89` |
| `02_Indexes/lifecycle-and-operating-modes-index.json` | `bd1392863af4149a025c301e93df9da8935b27be262b7c8ff49578655fd5008a` |
| `02_Indexes/project-index.json` | `1287c4c7a6c3ddbf7443de39c313cd17f10d805171b4fbc255b9aa089b76aa0b` |
| `02_Indexes/section-index.json` | `49ea20dc35901ed1a80743aca10b3daf122953365e3f7a76ae9a1aeafaee155f` |
| `02_Indexes/stage-1-index.json` | `923fbbd5b6a13d69a5983d8e1ce4503195f8f3dbf512726f104a29fd6d82aa87` |
| `03_Relationships/chapter-dependencies.json` | `39583ce2426fc8f83eb19bda2358356ca9d29ea214b317829ebf36b2def7c12b` |
| `03_Relationships/explicit-relationships.jsonl` | `74da91454111ff0fe9342f8f2012f30e4104e09a301bb99be82ece80d621c762` |
| `03_Relationships/section-links.jsonl` | `51a2dc0c6888618a3c895706da02752597b0922ccf70e7a0a12453f6d9260526` |
| `04_Governance/ATLAS_RETRIEVAL_RULES.md` | `3802ffd6a82808b1f78eb480b5e3f37580f51043d35254981c8bdc6f81dde864` |
| `04_Governance/CANONICAL_VS_RUNTIME.md` | `c9c959f85db91db552af62639913a5c7f640e7507875095685192daac7048b10` |
| `04_Governance/HUMAN_AUTHORITY_AND_APPROVAL.md` | `245d65cda3f8238db3763b5de17a15fdbc69c7b81f47b595a8ba8eb6272e5e49` |
| `04_Governance/KNOWLEDGE_AUTHORITY_RULES.md` | `296db45604d1db1971c273413c7ebde254a27dd4a6f6843715f593243c4017f5` |
| `04_Governance/PROJECT_SCOPE_AND_ISOLATION.md` | `f0718b1a5618d1c042dcf2c192a6d865caace6f2d14cc93cbcd19815d8b63785` |
| `05_Retrieval/citation-format.md` | `914668a81dbd124d8585093b82de03c380ee852dc74cfdc132836be79daff2ad` |
| `05_Retrieval/query-routing-rules.md` | `d10ddfa9ffa21eabac4d6efd767cfc5f83a671a1f8033422edfccffca70cb4c2` |
| `05_Retrieval/retrieval-examples.jsonl` | `d6e7d4f1939e61a91cdca2b512a9e57002cfb4c4731326fc74178bb81d256bd8` |
| `05_Retrieval/retrieval-schema.json` | `8d5b7eca544e6d2b50e6ef4734d3326431700017b92f2d263c43c70a13f7d2a2` |
| `06_Source_References/canonical-source-reference.md` | `8464ce27a009a57cac9fe5fd8b099f9077eac3eef02a163be6809181541344a0` |
| `06_Source_References/page-map.json` | `30e99c8da609d4444483d572702ac485f72946781afe1b3957d2dc059cbf6f7a` |
| `06_Source_References/professional-edition-reference.md` | `c28767212a1cd720ed569fc7fe7eb332fcb00f6a8d33e11204591028b2255c02` |
| `06_Source_References/source-map.json` | `72b094938655ff3a52d63bb19318e78dd93a59a34d1409439f251b1d8412f20d` |
| `07_Validation/ATLAS_KNOWLEDGE_VALIDATION_REPORT.md` | `17b915df83a279116052a6e90c277e7548777fdf53a331605c6e1b80dcc0a8a4` |
| `07_Validation/CONTENT_COMPLETENESS_REPORT.md` | `f77798593c1d4aaf170f7c541623330467f22c9e7cf2a8bc47be8f4a807104f3` |
| `07_Validation/ID_INTEGRITY_REPORT.md` | `daae71de6e0067bd80b3aaabf5f9c8ae3dbc1b315a4e335cf2a5d5b691a32cbe` |
| `07_Validation/RELATIONSHIP_PROVENANCE_REPORT.md` | `c87652ad93a4da71a0b9901c4b37b2bd1a71c430ebae8ca914d4e2bc3706dbb8` |
| `07_Validation/RETRIEVAL_TEST_REPORT.md` | `8aa549e456667a76d7a93b90c3b47171e8e4f199981540945d8c6fba28797d4a` |
| `07_Validation/retrieval-tests.jsonl` | `3ea3b821e43bd546ecba49f5040b835cbdbad6622dc754a4795c6d680dfa19b7` |
| `Build/build_atlas.py` | `97aa1346a6b520c08b14b4320b2cfacc40d66b4a690294b45802cf9235e75247` |
| `Build/build_atlas_docs.py` | `8b62185037099fdbb5590ee4d24c1de38eb633a8fd3b3d6bd647bad165bd5526` |
| `README.md` | `8b2f665edce16a92735f04528937492a5924d6ba13e22a0b0826c2ea594c1d42` |
