# Executive Intelligence — Atlas Knowledge Edition v1.0

Status: **ATLAS KNOWLEDGE EDITION v1.0 — LOCAL VALIDATION CANDIDATE**
(Not repo-integrated and not production-ingested.)

A machine-readable, traceable, retrieval-optimized representation of the already-locked
**Canonical v1.0** text. It is **not** a new book and **not** new doctrine.

- Canonical input SHA-256: `ee85a1a09968c585530869bcc8d06eda16e4e12a8d5b6f856af362e10fa555b8`
- Final Professional Edition SHA-256: `b0cbb84eb0a53265bcc03b97c5c780e436489aaacdde1e7092816aa039be6aa2`
- 32 chapters · 6705 section IDs · 55840 canonical blocks · 4 front-matter sections · 17 active diagrams · 10 navigational Parts

## Absolute knowledge rules

- Canonical target architecture is not the same as implemented runtime.
- Repository, schema, runtime, and deployment are authoritative for what is actually implemented.
- Documents, Memory, Knowledge, graph objects, or model outputs never create authority.
- Human authority, governance, approval gates, and project isolation still apply.
- A recommendation does not automatically become a decision.
- A decision does not automatically become an approval.
- An approval does not automatically become reusable policy or autonomy.
- Knowledge is evidence and context, not execution authority.
- The Atlas Knowledge Edition never grants Atlas the right to act outside existing runtime authority.

## Layout

- `01_Canonical_Knowledge/` — 32 chapter markdown files + section/block/front-matter JSONL (exact canonical text).
- `02_Indexes/` — chapter, section, concept, project, authority, governance, stage-1, lifecycle/operating,
  autonomy, decision/approval, and diagram indexes. Navigational summaries are marked `NON-CANONICAL RETRIEVAL AID`.
- `03_Relationships/` — explicit + structurally-explicit relationships only.
- `04_Governance/` — the binding knowledge-authority, canonical-vs-runtime, human-authority, project-scope, and retrieval rules.
- `05_Retrieval/` — documented retrieval schema, examples, routing rules, citation format. No embeddings, no vector DB.
- `06_Source_References/` — read-only source map + page map + source references.
- `07_Validation/` — validation, completeness, ID-integrity, relationship-provenance, and retrieval-test reports.
- `ATLAS_KNOWLEDGE_EDITION_MANIFEST.md` — full manifest with file checksums.

## Maturity & implementation

Every canonical section carries `implementation_status: unknown_not_verified_in_this_package`. This phase does not inspect the
Omnira repository; canonical doctrine describes the **target architecture**, not confirmed runtime.
